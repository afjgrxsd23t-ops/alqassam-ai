const MODEL = "@cf/meta/llama-3.1-8b-instruct";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/api/health") {
      return Response.json({ ok: true, ai: Boolean(env.AI) });
    }
    if (url.pathname === "/api/chat" && request.method === "POST") {
      return handleAI(request, env, "chat");
    }
    if (url.pathname === "/api/build" && request.method === "POST") {
      return handleAI(request, env, "build");
    }
    if (url.pathname === "/api/chat" || url.pathname === "/api/build") {
      return Response.json({ error: "استخدم POST لإرسال الطلب." }, { status: 405 });
    }
    if (env.ASSETS) return env.ASSETS.fetch(request);
    return new Response("القسام AI: أضف ملفات public واربط ASSETS.", { status: 500 });
  }
};

async function handleAI(request, env, mode) {
  try {
    if (!env.AI) {
      return Response.json({ error: "Workers AI غير مربوط. أضف AI binding باسم AI في إعدادات Worker." }, { status: 503 });
    }
    const body = await request.json();
    const prompt = String(body.prompt || "").trim();
    if (!prompt) return Response.json({ error: "اكتب طلبك أولاً." }, { status: 400 });

    const messages = [{
      role: "system",
      content: mode === "build"
        ? "You are Alqassam AI App Builder. Return ONLY one complete standalone HTML document with embedded CSS and JavaScript. Make it mobile-first, responsive, accessible, and Arabic RTL if the request is Arabic. Implement front-end interactions where practical. Do not claim backend, login, database, or real messaging works unless implemented. Never include secret API keys. No Markdown fences."
        : "أنت القسام AI، مساعد عربي ودود. أجب بوضوح باللغة المناسبة للمستخدم، وساعد في البرمجة والتصميم. لا تدّع تنفيذ إجراءات خارج المحادثة، ولا تطلب كلمات المرور أو المفاتيح السرية."
    }];

    if (mode === "chat" && Array.isArray(body.history)) {
      for (const item of body.history.slice(-10)) {
        if (item && ["user", "assistant"].includes(item.role) && typeof item.content === "string") {
          messages.push({ role: item.role, content: item.content.slice(0, 3500) });
        }
      }
    }
    messages.push({ role: "user", content: prompt.slice(0, 9000) });

    const result = await env.AI.run(MODEL, {
      messages,
      max_tokens: mode === "build" ? 6000 : 1200
    });
    let answer = String(result?.response || "").trim();
    if (mode === "build") {
      answer = answer.replace(/^```(?:html)?\s*/i, "").replace(/\s*```$/, "").trim();
      if (!/<html[\s>]/i.test(answer)) {
        return Response.json({ error: "لم يُرجع النموذج ملف HTML كاملاً. اختصر وصف التطبيق وحاول مجددًا." }, { status: 502 });
      }
    }
    return Response.json({ answer });
  } catch (error) {
    return Response.json({
      error: "تعذر تشغيل الذكاء الاصطناعي. تحقق من ربط Workers AI وتوفر النموذج وحدود الاستخدام."
    }, { status: 500 });
  }
}
